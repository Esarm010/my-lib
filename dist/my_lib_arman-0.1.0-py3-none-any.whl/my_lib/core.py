from importlib import resources

def hello(name: str) -> str:
    return f"Привет, {name}!"

def allan(name: str) -> str:
    return f"Allan Zhavat, {name}!"